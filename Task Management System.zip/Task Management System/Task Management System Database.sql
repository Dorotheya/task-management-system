CREATE SCHEMA `task_database`;

CREATE TABLE `task_database`.`user table`( `user id` INT NOT NULL, `name` VARCHAR(45) NOT NULL, PRIMARY KEY (`user id`));

SELECT * FROM task_database.`user table`;

INSERT INTO `task_database`.`user table` (`user id`, `name`) VALUES ('101', 'Asen');
INSERT INTO `task_database`.`user table` (`user id`, `name`) VALUES ('102', 'Jessica');
INSERT INTO `task_database`.`user table` (`user id`, `name`) VALUES ('103', 'Liza');
INSERT INTO `task_database`.`user table` (`user id`, `name`) VALUES ('104', 'Ivo');
INSERT INTO `task_database`.`user table` (`user id`, `name`) VALUES ('105', 'Simeon');

ALTER TABLE `task_database`.`user table` 
ADD COLUMN `group` VARCHAR(45) NOT NULL AFTER `name`,
ADD COLUMN `position` VARCHAR(45) NOT NULL AFTER `group`;

UPDATE `task_database`.`user table` SET `group` = 'PHP Delevoper', `position` = 'member' WHERE (`user id` = '101');
UPDATE `task_database`.`user table` SET `group` = 'C# Developer', `position` = 'member' WHERE (`user id` = '102');
UPDATE `task_database`.`user table` SET `group` = 'C# Developer', `position` = 'leader' WHERE (`user id` = '103');
UPDATE `task_database`.`user table` SET `group` = 'Java', `position` = 'member' WHERE (`user id` = '104');
UPDATE `task_database`.`user table` SET `group` = 'PHP Developer', `position` = 'member' WHERE (`user id` = '105');

CREATE TABLE `task_database`.`status`( `status id` INT NOT NULL, `status name` VARCHAR(45) NOT NULL, PRIMARY KEY (`status id`));

INSERT INTO `task_database`.`status` (`status id`, `status name`) VALUES ('101', 'In progress');
INSERT INTO `task_database`.`status` (`status id`, `status name`) VALUES ('102', 'On hold');
INSERT INTO `task_database`.`status` (`status id`, `status name`) VALUES ('103', 'Done');

CREATE TABLE `task_database`.`type` (`type id` INT NOT NULL, `type name` VARCHAR(45) NOT NULL, PRIMARY KEY (`type id`));

INSERT INTO `task_database`.`type` (`type id`, `type name`) VALUES ('101', 'Basic');
INSERT INTO `task_database`.`type` (`type id`, `type name`) VALUES ('102', 'Intermediate');
INSERT INTO `task_database`.`type` (`type id`, `type name`) VALUES ('103', 'Advanced');

CREATE SCHEMA `comments`;

CREATE TABLE `comments`.`type` (`type id` INT NOT NULL, `type name` VARCHAR(45) NOT NULL, PRIMARY KEY (`type id`));
  
SELECT * FROM comments.type;
  
INSERT INTO `comments`.`type` (`type id`, `type name`) VALUES ('101', 'Single line');
INSERT INTO `comments`.`type` (`type id`, `type name`) VALUES ('102', 'Multiline');



